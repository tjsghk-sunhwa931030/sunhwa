package mybatis;

public class UInfoArrVO {

	private String[] lst_location_list;
	private String[] lst_ptype_list;
	private String utype;
	private String[] uinfoarr;
	
	
	
	
	
	
}
